import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class RandomSort {

    public static void main(String[] args) throws InterruptedException {
        List<Integer> numbers = new ArrayList<>();

        Thread generator = new Thread(new Runnable() {
            public void run() {
                Random random = new Random();
                for (int i = 0; i < 100; i++) {
                    int number = random.nextInt(1000);
                    numbers.add(number);
                }
            }
        });

        Thread sorter = new Thread(new Runnable() {
            public void run() {
                Collections.sort(numbers);
            }
        });

        generator.start();
        sorter.start();

        generator.join();
        sorter.join();

        System.out.println(numbers);
    }
}